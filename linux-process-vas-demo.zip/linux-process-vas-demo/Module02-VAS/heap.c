#include <stdio.h>

int main() 
{
  char ch;
  void *ptr;
  scanf("%c",&ch);
  ptr = malloc(1048576); // 1MB
  scanf("%c",&ch);
}

